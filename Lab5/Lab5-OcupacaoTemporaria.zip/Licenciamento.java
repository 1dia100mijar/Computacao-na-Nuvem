package cn.operations;

import java.util.Date;

public class Licenciamento {
    public String code;
    public Date dtLicenc;
    public Licenciamento() {}
}
