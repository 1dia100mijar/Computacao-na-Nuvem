public class OcupacaoTemporaria {
    public int ID;
    public Localizacao location;
    public Evento event;

public OcupacaoTemporaria() {}

}
