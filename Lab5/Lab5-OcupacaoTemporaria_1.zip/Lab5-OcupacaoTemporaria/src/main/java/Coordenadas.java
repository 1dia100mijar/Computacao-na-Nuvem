public class Coordenadas {
  public Double X;
  public Double Y;

    public Coordenadas() {}
}
