package primesclient;

public class ClientApp {
    public static void main(String[] args) {
        System.out.println("Hello from ClientApp!");
    }
}
