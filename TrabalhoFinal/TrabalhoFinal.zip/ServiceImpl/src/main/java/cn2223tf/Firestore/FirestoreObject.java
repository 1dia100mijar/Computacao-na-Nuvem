package cn2223tf.Firestore;

import java.util.ArrayList;

public class FirestoreObject {
    public String blobImage;
    public String blobMap;
    public String bucket;
    public ArrayList<LandmarkFirestore> landmarks;
    public String requestId;
    public FirestoreObject(){}
}
