package cn2223tf.Firestore;

public class FirestoreFilteredDocument {
    public String name;
    public String blobImage;
}
