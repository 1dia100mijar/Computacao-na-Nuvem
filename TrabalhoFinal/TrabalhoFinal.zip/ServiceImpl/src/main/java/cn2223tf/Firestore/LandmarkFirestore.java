package cn2223tf.Firestore;

public class LandmarkFirestore {
    public double latitude;
    public double longitude;
    public String name;
    public double score;
}
