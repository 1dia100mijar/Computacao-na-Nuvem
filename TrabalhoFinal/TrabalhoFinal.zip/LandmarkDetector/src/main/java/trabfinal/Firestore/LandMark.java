package trabfinal.Firestore;

public class LandMark {
    public String name;
    public float score;
    public double latitude;
    public double longitude;

    public LandMark(){}
}
